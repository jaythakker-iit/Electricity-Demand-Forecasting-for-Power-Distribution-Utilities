"""Evaluator gate for Phase 7: comparison tables are internally consistent."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import compare as cp  # noqa: E402
from src import config, evaluation as ev, features  # noqa: E402

def test_block_bootstrap_centres_on_mae():
    rng = np.random.default_rng(2)
    ae = pd.DataFrame({"a": np.abs(rng.normal(size=5000)) * 50})
    b = cp.block_bootstrap(ae, block=168, n_boot=500)
    assert abs(b.mean() - ae["a"].mean()) < 1.0


def test_compare_all_is_single_source_of_truth():
    tab = pd.read_csv(config.TABLE_DIR / "compare_all.csv")
    p = ev.load_all_predictions()
    for m in cp.FINAL:
        g = p[(p.split == "test") & (p.model == m)]
        row = tab[(tab.split == "test") & (tab.model == m) & (tab.subset == "all")].iloc[0]
        assert np.mean(np.abs(g.y_true - g.y_pred)) == pytest.approx(row.MAE, abs=1e-3)


def test_ablation_full_set_reproduces_phase5_xgboost():
    """'C_+festival' == the Phase 5 tree feature set, so its test MAE must match the Phase 5 model
    (up to seed averaging: within 1 MW)."""
    assert set(features.ABLATION["C_+festival"]) == set(features.FEATURE_SETS["tree"])
    abl = pd.read_csv(config.TABLE_DIR / "phase7_ablation.csv")
    full = abl[(abl.feature_set == "C_+festival") & (abl.split == "test")].MAE_ensemble.iloc[0]
    xgb = pd.read_csv(config.TABLE_DIR / "compare_all.csv")
    ref = xgb[(xgb.split == "test") & (xgb.model == "XGBoost") & (xgb.subset == "all")].MAE.iloc[0]
    assert abs(full - ref) < 1.0


def test_walkforward_uses_only_past_data():
    wf = pd.read_csv(config.TABLE_DIR / "phase7_walkforward_predictions.csv", parse_dates=["timestamp"])
    for mth, g in wf.groupby("month"):
        assert g.timestamp.min() >= pd.Period(mth).start_time


