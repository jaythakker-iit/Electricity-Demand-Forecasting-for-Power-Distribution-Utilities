"""Build notebooks/06_evaluation.ipynb after the Phase 7 scripts are run."""
from pathlib import Path

import nbformat as nbf

cells = []


def md(text):
    cells.append(nbf.v4.new_markdown_cell(text.strip()))


def code(text):
    cells.append(nbf.v4.new_code_cell(text.strip()))


md("""
# 06 — Evaluation: model accuracy and error analysis

**EM 630 · Electricity Demand Forecasting · Phase 7**

This notebook compares the final models using MAE and moving-block-bootstrap confidence intervals, then examines errors by hour, demand level, day type, peak period and test month. It also includes walk-forward evaluation and a feature-group ablation.
""")
code("""
import sys, warnings
from pathlib import Path
sys.path.insert(0, str(Path.cwd().parent))
warnings.filterwarnings("ignore")
import pandas as pd
from IPython.display import Image, display
from src import config, compare as cp
TD = config.TABLE_DIR
def show(name, width=1000):
    display(Image(filename=str(config.FIG_DIR / f"{name}.png"), width=width))
print("Final models:", cp.FINAL)
""")
md("""
## 1. Overall accuracy

All models are scored on the same chronological test rows. The confidence intervals use weekly moving-block resampling, preserving the serial structure within each sampled week. They describe uncertainty in MAE estimates and are not hypothesis tests.
""")
code("""
tab = pd.read_csv(TD / "compare_all.csv")
tab[(tab.split == "test") & (tab.subset == "all") & tab.final_contender][["model", "family", "MAE", "RMSE", "MAPE", "R2", "Bias", "skill_vs_step"]].sort_values("MAE")
""")
code("""
pd.read_csv(TD / "compare_ci.csv")
show("F28_final_ranking_ci")
""")
code("""
pd.read_csv(TD / "compare_gaps.csv")
show("F29_mae_gap_matrix", 850)
""")
md("""
## 2. Where do errors occur?
""")
code("""
show("F30_error_by_hour")
show("F31_error_breakdowns", 1100)
show("F32_peak_hours", 1100)
""")
md("""
## 3. Walk-forward evaluation

For each test month, models are refit using only observations before that month, then evaluated on that month.
""")
code("""
show("F33_walkforward", 1100)
wf = pd.read_csv(TD / "phase7_walkforward.csv")
wf.pivot(index="month", columns="model", values="MAE_walkforward").round(1)
""")
md("""
## 4. Feature-group ablation

XGBoost is refit with cumulative feature groups to show how the MAE changes when weather and festival variables are included.
""")
code("""
pd.read_csv(TD / "phase7_ablation.csv").round(2)
show("F34_ablation")
""")
md("""
## 5. Residual pattern
""")
code("""
show("F36_week_and_residual_acf", 1100)
""")

nb = nbf.v4.new_notebook()
nb["cells"] = cells
nb["metadata"]["kernelspec"] = {"name": "python3", "display_name": "Python 3", "language": "python"}
out = Path(__file__).with_name("06_evaluation.ipynb")
nbf.write(nb, out)
print("wrote", out)
