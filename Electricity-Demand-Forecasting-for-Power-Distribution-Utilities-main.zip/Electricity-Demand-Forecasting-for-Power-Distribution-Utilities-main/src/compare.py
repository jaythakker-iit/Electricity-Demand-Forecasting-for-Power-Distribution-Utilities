"""Phase 7: comparison and error-breakdown helpers.

Moving-block bootstrap
----------------------
Resample whole blocks of consecutive hours (default 168 h = 1 week) so the bootstrap keeps the
daily/weekly dependence. Gives confidence intervals for MAE and for MAE differences without
assuming independence.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

FINAL = ["Naive-1 (persistence)", "Naive-1 + hourly step", "Lasso + hour×month",
         "Random Forest", "XGBoost"]
SHORT = {"Naive-1 (persistence)": "Persistence", "Naive-1 + hourly step": "Step baseline",
         "Lasso + hour×month": "Lasso+h×m", "Random Forest": "Random Forest", "XGBoost": "XGBoost",
         "Decision Tree": "Decision Tree"}


def wide(pred_long: pd.DataFrame, split: str, models=FINAL) -> pd.DataFrame:
    """timestamp x model matrix of predictions + y_true; asserts identical rows for all models."""
    p = pred_long[(pred_long.split == split) & pred_long.model.isin(models)]
    w = p.pivot_table(index="timestamp", columns="model", values="y_pred")
    y = p.groupby("timestamp")["y_true"].first()
    assert w.notna().all().all(), "models are not scored on identical rows"
    w = w[[m for m in models if m in w.columns]]
    w.insert(0, "y_true", y)
    return w.sort_index()


def block_bootstrap(abs_err: pd.DataFrame, block: int = 168, n_boot: int = 2000, seed: int = 42) -> np.ndarray:
    """Return an (n_boot x n_models) array of bootstrap MAEs (moving-block resampling of rows)."""
    rng = np.random.default_rng(seed)
    A = abs_err.values
    T = len(A)
    n_blocks = int(np.ceil(T / block))
    starts = rng.integers(0, T - block + 1, size=(n_boot, n_blocks))
    out = np.empty((n_boot, A.shape[1]))
    offs = np.arange(block)
    for b in range(n_boot):
        idx = (starts[b][:, None] + offs).ravel()[:T]
        out[b] = A[idx].mean(0)
    return out


def breakdown(w: pd.DataFrame, by: pd.Series, models=FINAL) -> pd.DataFrame:
    """MAE (and n) of each model within groups defined by `by` (aligned to w.index)."""
    ae = w[models].sub(w["y_true"], axis=0).abs()
    g = ae.groupby(by.reindex(w.index).values)
    t = g.mean()
    t["n"] = g.size()
    return t
