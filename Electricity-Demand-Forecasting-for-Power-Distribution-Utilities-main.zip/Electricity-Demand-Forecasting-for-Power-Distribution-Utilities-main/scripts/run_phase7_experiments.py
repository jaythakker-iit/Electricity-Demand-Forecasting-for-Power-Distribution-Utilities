"""Phase 7 experiments (fixed hyperparameters from Phases 4-5; no new tuning).

E1 Walk-forward: for each calendar month of the test period, refit on ALL data before that month
   and forecast the month. Compared with the static models (fit once on Train+Val). Answers: does
   performance hold month by month, and does monthly retraining help?
E2 Feature-group ablation with XGBoost (delta target, 3 seeds): which feature groups matter?
   'C_+festival' is the full tree feature set = the Phase 5 model (consistency check).
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.ensemble import RandomForestRegressor  # noqa: E402
from xgboost import XGBRegressor  # noqa: E402

from src import baselines, config, data, evaluation as ev, features, split  # noqa: E402
from src import linear_models as lm  # noqa: E402
from src import tree_models as tm  # noqa: E402

T = config.TARGET
FT = features.FEATURE_SETS["tree"]
feats = features.build_features(data.load_clean())
sp = split.chronological_split(feats)
t0 = time.time()

best = pd.read_csv(config.TABLE_DIR / "phase5_best_params.csv")
alphas = pd.read_csv(config.TABLE_DIR / "phase4_alphas.csv")


def xgb_params():
    r = best[(best.model == "XGBoost") & (best.split == "test")].iloc[0]
    return dict(n_estimators=int(r.n_estimators), learning_rate=float(r.learning_rate), max_depth=int(r.max_depth),
                min_child_weight=float(r.min_child_weight), subsample=float(r.subsample),
                colsample_bytree=float(r.colsample_bytree), reg_lambda=float(r.reg_lambda), reg_alpha=float(r.reg_alpha))


def rf_params():
    r = best[(best.model == "Random Forest") & (best.split == "test")].iloc[0]
    md = None if str(r.max_depth) in ("None", "nan") else int(float(r.max_depth))
    return dict(n_estimators=200, max_depth=md, min_samples_leaf=int(float(r.min_samples_leaf)),
                max_features=float(r.max_features))


def make_xgb(seed=config.SEED):
    return tm.TargetMode(XGBRegressor(tree_method="hist", n_jobs=-1, random_state=seed, verbosity=0, **xgb_params()), "delta")


def make_rf():
    return tm.TargetMode(RandomForestRegressor(n_jobs=-1, random_state=config.SEED, **rf_params()), "delta")


lasso_alpha = float(alphas[(alphas.model == "Lasso + hour×month") & (alphas.split == "test")].alpha_best.iloc[0])
# ================================================================ E1 walk-forward
months = pd.period_range(sp.test.index.min(), sp.test.index.max(), freq="M")
wf = []
for mth in months:
    start = mth.start_time
    fit = feats[feats.index < start]
    tgt = sp.test[(sp.test.index >= start) & (sp.test.index <= mth.end_time)]
    if len(tgt) == 0:
        continue
    y = tgt[T]
    out = {"Naive-1 + hourly step": baselines.PersistencePlusStep().fit(fit).predict(tgt)}
    lm_m = lm.fit_final(features.linear_design(fit, True), fit[T], "lasso", lasso_alpha)
    out["Lasso + hour×month"] = lm_m.predict(features.linear_design(tgt, True))
    out["XGBoost"] = make_xgb().fit(fit[FT], fit[T]).predict(tgt[FT])
    out["Random Forest"] = make_rf().fit(fit[FT], fit[T]).predict(tgt[FT])
    for m, p in out.items():
        wf.append(ev.to_long(m, "test", y, p).assign(month=str(mth), fit_rows=len(fit)))
    print(f"walk-forward {mth}: fit rows {len(fit):,}, target hours {len(tgt)}  ({time.time() - t0:.0f}s)", flush=True)
wf = pd.concat(wf, ignore_index=True)
wf.to_csv(config.TABLE_DIR / "phase7_walkforward_predictions.csv", index=False)

static = ev.load_all_predictions()
static = static[(static.split == "test") & static.model.isin(wf.model.unique())].copy()
static["month"] = static.timestamp.dt.to_period("M").astype(str)
rows = []
for (m, mth), g in wf.groupby(["model", "month"]):
    s = static[(static.model == m) & (static.month == mth)]
    rows.append({"model": m, "month": mth, "n": len(g),
                 "MAE_walkforward": np.mean(np.abs(g.y_true - g.y_pred)),
                 "MAE_static": np.mean(np.abs(s.y_true - s.y_pred))})
wft = pd.DataFrame(rows)
wft.round(3).to_csv(config.TABLE_DIR / "phase7_walkforward.csv", index=False)
print(wft.pivot(index="month", columns="model", values="MAE_walkforward").round(1))

# ================================================================ E2 ablation
abl_rows, abl_preds = [], []
for setname, cols in features.ABLATION.items():
    for split_name, fit_part, ev_part in [("val", sp.train, sp.val), ("test", sp.dev, sp.test)]:
        ps_ = [make_xgb(s).fit(fit_part[cols], fit_part[T]).predict(ev_part[cols]) for s in (42, 7, 2026)]
        p = np.mean(ps_, 0)
        maes = [np.mean(np.abs(ev_part[T] - q)) for q in ps_]
        abl_rows.append({"feature_set": setname, "split": split_name, "n_features": len(cols),
                         "MAE_ensemble": np.mean(np.abs(ev_part[T] - p)), "MAE_seed_mean": np.mean(maes),
                         "MAE_seed_std": np.std(maes, ddof=1)})
        if split_name == "test":
            abl_preds.append(pd.DataFrame({"timestamp": ev_part.index, "set": setname, "y_true": ev_part[T].values, "y_pred": p}))
    print(f"ablation {setname} done ({time.time() - t0:.0f}s)", flush=True)
abl = pd.DataFrame(abl_rows)
ap = pd.concat(abl_preds).pivot(index="timestamp", columns="set", values="y_pred")
yt = pd.concat(abl_preds).groupby("timestamp").y_true.first()
abl.round(3).to_csv(config.TABLE_DIR / "phase7_ablation.csv", index=False)
print(abl.round(2).to_string(index=False))
print(f"done ({time.time() - t0:.0f}s)")
